# Nhập dữ liệu Power BI

Dữ liệu giả lập. Mở Power BI Desktop, Home → Enter data. Sao chép riêng nội dung từng khối bên dưới, gồm hàng tiêu đề, rồi dán vào ô đầu tiên. Nếu tiêu đề chưa được nhận, chọn Use first row as headers. Đặt đúng tên bảng rồi Load.

Không dán các dòng có dấu ``` hoặc tên bảng. Trong Table view, đặt Ngay thành Date ở cả hai bảng có ngày; kWh thành Whole number; MaKH/MaDonVi thành Text. Các ngày mẫu được ghi theo ISO YYYY-MM-DD.

## DimDonVi

```text
MaDonVi	TenDonVi
DV_A	Dien luc A
DV_B	Dien luc B
DV_C	Dien luc C
```

## DimNgay

```text
Ngay	Thang
2026-09-01	2026-09
2026-09-02	2026-09
```

## FactDien

```text
MaKH	MaDonVi	Ngay	kWh
KH001	DV_A	2026-09-01	100
KH002	DV_A	2026-09-01	150
KH003	DV_A	2026-09-01	200
KH004	DV_B	2026-09-01	250
KH005	DV_B	2026-09-01	300
KH006	DV_C	2026-09-01	400
KH001	DV_A	2026-09-02	110
KH004	DV_B	2026-09-02	260
```

Tạo hai quan hệ một–nhiều đang hoạt động, hướng Single: DimDonVi[MaDonVi] → FactDien[MaDonVi] và DimNgay[Ngay] → FactDien[Ngay].

Làm từng bài BI trên web. Lưu file và ảnh trên máy, nhập kết quả vào bài cá nhân. Bài service là tùy chọn và cần tài khoản/môi trường thực hành phù hợp.