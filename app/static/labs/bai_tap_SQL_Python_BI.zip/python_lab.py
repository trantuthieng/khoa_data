"""Python cá nhân: dữ liệu giả lập, không cần thư viện ngoài."""
import json
from pathlib import Path

rows = json.loads(Path(__file__).with_name("customers.json").read_text(encoding="utf-8"))

# BÀI LÀM: thay phần dưới bằng mã của từng bài Python trên web.
print("Đã đọc dữ liệu mẫu. Điền bài làm tại đây.")
