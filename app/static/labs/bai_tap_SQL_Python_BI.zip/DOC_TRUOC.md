# Bộ bài cá nhân SQL, Python và Power BI

Tất cả dữ liệu trong gói đều là giả lập, không phải khách hàng thật.

1. Giải nén vào một thư mục riêng. Giữ customers.json cạnh hai file .py.
2. SQL/Python: dùng Python 3, không cần pandas hoặc máy chủ cơ sở dữ liệu.
   Mở Terminal trong thư mục, chạy `python sql_lab.py` hoặc `python python_lab.py`.
   Windows có thể dùng `py` thay `python`. Bài SQL 01–07 sửa query; SQL 08 thay phần chạy query bằng mã tham số hóa của đề. Bài Python thay phần BÀI LÀM.
3. BI: đọc huong_dan_BI.md và nhập ba bảng bằng Enter data. Chỉ BI 10 cần service.
4. Đề và nơi nộp nằm trên web lớp học. Mỗi bài làm riêng. Ghi mã/thao tác, kết quả và giải thích; chọn đúng trạng thái đã chạy/chưa chạy/còn lỗi.
5. Bài SQL/Python dùng bộ customers có 6 dòng, mỗi khách một dòng. BI dùng 8 dòng theo ngày, có hai khách lặp lại ở ngày thứ hai. Không trộn hai mức chi tiết.
6. Lưu file/ảnh ở máy để giảng viên đối chiếu. Web hiện chỉ nhận nội dung, chưa nhận tệp đính kèm.

Gói này không kèm đáp án. Giảng viên mở gợi ý chữa bài sau khi lớp nộp.
