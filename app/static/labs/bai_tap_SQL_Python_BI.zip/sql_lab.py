"""SQL cá nhân: dữ liệu giả lập, chạy hoàn toàn trong bộ nhớ."""
import json
import sqlite3
from pathlib import Path

rows = json.loads(Path(__file__).with_name("customers.json").read_text(encoding="utf-8"))
connection = sqlite3.connect(":memory:")
connection.execute("CREATE TABLE customers (id TEXT, name TEXT, phone TEXT, address TEXT, region TEXT, kwh INTEGER)")
connection.executemany("INSERT INTO customers VALUES (:id,:name,:phone,:address,:region,:kwh)", rows)

# BÀI LÀM: thay query bằng câu SQL của từng bài 01–07.
query = "SELECT * FROM customers ORDER BY id;"
for record in connection.execute(query).fetchall():
    print(record)

# Bài SQL 08: giữ phần tạo connection ở trên, thay phần query/vòng lặp
# bằng đoạn mẫu của SQL 08 trên web rồi điền các chỗ trống.
